export const log = console.log;
