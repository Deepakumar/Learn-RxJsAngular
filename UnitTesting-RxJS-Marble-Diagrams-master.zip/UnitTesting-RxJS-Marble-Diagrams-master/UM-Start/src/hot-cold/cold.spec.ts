import { cold, getTestScheduler } from 'jasmine-marbles';
import { of, Observable, throwError, from } from 'rxjs';

describe('COLD', () => {
  it('of with one value', () => {

  });

  it('of with 2 values', () => {

  });

  it('from', () => {

  });

  it('should trim the spaces', () => {
  });
});
