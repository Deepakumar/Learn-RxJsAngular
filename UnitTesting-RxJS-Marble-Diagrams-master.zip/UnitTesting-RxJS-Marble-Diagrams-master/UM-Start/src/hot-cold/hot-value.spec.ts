import { hot, cold } from 'jasmine-marbles';
import { from } from 'rxjs';
import { share } from 'rxjs/operators';

describe('hot', () => {
  it('should create hot observable', () => {
    
  });

});
